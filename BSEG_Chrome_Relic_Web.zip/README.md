# BSEG — CHROME RELIC / EDITION 004

**BONEVIOLENT SPECTRAL EFFECTS GOBLIN**  
*by ghostgirl 空舞*

Built on the previously developed VFX-02 compositor with layer effects, masks, audio modulation, local import, timeline and export. This edition updates the actual interactive editor — header, chrome typography, hardware surfaces, buttons, effect racks, 3D monitor and demo canvas.

## Open on Mac

Download `BSEG-offline.html` and open in **Chrome for macOS**. Nothing needs installing. Google Fonts are optional (load when connected); CSS fallback fonts preserve the visual treatment offline. Your media stays in your browser.

## Publish the web edition

Upload `index.html` in this folder to a static host such as Netlify Drop. The website is public by default; no account or cloud storage backend has been added.

## Important notes

- This is the UI redesign of an experimental prototype, not feature parity with Ladybug.
- WebGL2 and recording support depend on browser capabilities.
- Original effect processing IDs are retained for backwards compatibility with presets/project settings.
- Chrome highlights rely on CSS reflections, 3D transforms, overlays and hardware-style bevels rather than large pastel gradients.
- The long name is dominant. **BSEG** is the system mark and **by ghostgirl 空舞** is small artist credit.
